setTimeout(function() {
  console.log('Hi')
}, 2000)

setTimeout(function() {
  console.log('TEST')
})

console.log('Hello')
