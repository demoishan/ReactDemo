var express = require('express')
var path = require('path')

var PORT = process.env.PORT || 3000

var app = express()

app.set('view engine', 'ejs')

app.get('/', function(req, res) { 
  res.render('index', {
    title: 'Home',
    body: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque nulla orci, blandit nec aliquam sit amet, auctor vel sem. Nulla sit amet congue neque, at elementum augue. Sed eleifend tortor non convallis blandit. Donec feugiat consectetur euismod. Sed turpis dui, semper sit amet luctus egestas, euismod in tortor. Nullam elementum ultrices elementum. Sed tristique blandit purus id semper. Quisque interdum vel neque et cursus. Quisque et lectus porttitor, volutpat elit at, tempor tellus. Fusce pharetra, turpis blandit gravida congue, arcu neque dapibus ante, et lobortis ligula mi at ligula. Proin ullamcorper orci velit, vel feugiat ante imperdiet quis. Praesent rhoncus odio ligula, et eleifend lectus mollis non. Nulla eros urna, auctor eget magna pharetra, imperdiet venenatis diam. Vestibulum vehicula, nunc vel tempus ullamcorper, nibh diam fringilla nulla, non gravida enim nisl eu ligula. Nam ipsum arcu, mollis sed tortor eget, ultrices imperdiet quam. Vestibulum nec porta nulla, faucibus vestibulum felis.'
  })
})

app.get('/about-us', function(req, res) {
  res.render('index', {
    title: 'About Us',
    body: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque nulla orci, blandit nec aliquam sit amet, auctor vel sem. Nulla sit amet congue neque, at elementum augue. Sed eleifend tortor non convallis blandit. Donec feugiat consectetur euismod. Sed turpis dui, semper sit amet luctus egestas, euismod in tortor. Nullam elementum ultrices elementum. Sed tristique blandit purus id semper. Quisque interdum vel neque et cursus. Quisque et lectus porttitor, volutpat elit at, tempor tellus. Fusce pharetra, turpis blandit gravida congue, arcu neque dapibus ante, et lobortis ligula mi at ligula. Proin ullamcorper orci velit, vel feugiat ante imperdiet quis. Praesent rhoncus odio ligula, et eleifend lectus mollis non. Nulla eros urna, auctor eget magna pharetra, imperdiet venenatis diam. Vestibulum vehicula, nunc vel tempus ullamcorper, nibh diam fringilla nulla, non gravida enim nisl eu ligula. Nam ipsum arcu, mollis sed tortor eget, ultrices imperdiet quam. Vestibulum nec porta nulla, faucibus vestibulum felis.'
  })
})

app.get('/services', function(req, res) {
  res.render('index', {
    title: 'Services',
    body: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque nulla orci, blandit nec aliquam sit amet, auctor vel sem. Nulla sit amet congue neque, at elementum augue. Sed eleifend tortor non convallis blandit. Donec feugiat consectetur euismod. Sed turpis dui, semper sit amet luctus egestas, euismod in tortor. Nullam elementum ultrices elementum. Sed tristique blandit purus id semper. Quisque interdum vel neque et cursus. Quisque et lectus porttitor, volutpat elit at, tempor tellus. Fusce pharetra, turpis blandit gravida congue, arcu neque dapibus ante, et lobortis ligula mi at ligula. Proin ullamcorper orci velit, vel feugiat ante imperdiet quis. Praesent rhoncus odio ligula, et eleifend lectus mollis non. Nulla eros urna, auctor eget magna pharetra, imperdiet venenatis diam. Vestibulum vehicula, nunc vel tempus ullamcorper, nibh diam fringilla nulla, non gravida enim nisl eu ligula. Nam ipsum arcu, mollis sed tortor eget, ultrices imperdiet quam. Vestibulum nec porta nulla, faucibus vestibulum felis.',
    services: [
      { title: 'Web Design', description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque nulla orci, blandit nec aliquam sit amet, auctor vel sem. Nulla sit amet congue neque, at elementum augue. Sed eleifend tortor non convallis blandit. Donec feugiat consectetur euismod. Sed turpis dui, semper sit amet luctus egestas, euismod in tortor.' },
      { title: 'Web Development', description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque nulla orci, blandit nec aliquam sit amet, auctor vel sem. Nulla sit amet congue neque, at elementum augue. Sed eleifend tortor non convallis blandit. Donec feugiat consectetur euismod. Sed turpis dui, semper sit amet luctus egestas, euismod in tortor.' },
      { title: 'Block Chain', description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque nulla orci, blandit nec aliquam sit amet, auctor vel sem. Nulla sit amet congue neque, at elementum augue. Sed eleifend tortor non convallis blandit. Donec feugiat consectetur euismod. Sed turpis dui, semper sit amet luctus egestas, euismod in tortor.' },
      { title: 'SEO', description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque nulla orci, blandit nec aliquam sit amet, auctor vel sem. Nulla sit amet congue neque, at elementum augue. Sed eleifend tortor non convallis blandit. Donec feugiat consectetur euismod. Sed turpis dui, semper sit amet luctus egestas, euismod in tortor.' },
    ]
  })
})

app.get('/contact-us', function(req, res) {
  res.render('index', {
    title: 'Contact Us',
    body: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque nulla orci, blandit nec aliquam sit amet, auctor vel sem. Nulla sit amet congue neque, at elementum augue. Sed eleifend tortor non convallis blandit. Donec feugiat consectetur euismod. Sed turpis dui, semper sit amet luctus egestas, euismod in tortor. Nullam elementum ultrices elementum. Sed tristique blandit purus id semper. Quisque interdum vel neque et cursus. Quisque et lectus porttitor, volutpat elit at, tempor tellus. Fusce pharetra, turpis blandit gravida congue, arcu neque dapibus ante, et lobortis ligula mi at ligula. Proin ullamcorper orci velit, vel feugiat ante imperdiet quis. Praesent rhoncus odio ligula, et eleifend lectus mollis non. Nulla eros urna, auctor eget magna pharetra, imperdiet venenatis diam. Vestibulum vehicula, nunc vel tempus ullamcorper, nibh diam fringilla nulla, non gravida enim nisl eu ligula. Nam ipsum arcu, mollis sed tortor eget, ultrices imperdiet quam. Vestibulum nec porta nulla, faucibus vestibulum felis.'
  })
})

app.get('/*', function(req, res) {
  res.render('index', {
    title: '404 Page',
    body: 'Page Not Found'
  })
})

app.listen(PORT, function() {
  console.log('Express Server started on PORT ' + PORT)
})