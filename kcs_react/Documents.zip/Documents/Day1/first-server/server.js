var http = require('http')

var PORT = process.env.PORT || 3000

var server = http.createServer(function(req, res) {
  res.setHeader('Content-type', 'text/html')
  res.setHeader('Status', 200)
  res.end('<h1>Hello World!!!</h1>')
})

server.listen(PORT, function() {
  console.log('Server Running on PORT :: ' + PORT)
})