var age1 = 20
var age2 = '20'

console.log(age1 === age2)