var express = require('express')
var http = require('http')
var socketio = require('socket.io')
var faker = require('faker')

var app = express()
var server = http.createServer(app)
var io = socketio(server)

var users = [];

io.on('connection', function(socket) {
  var userFullName = faker.name.findName();

  console.log(userFullName + ' connected')
  users.push(userFullName)

  socket.emit('your name', userFullName)
  io.emit('all users', users)

  socket.on('before disconnect', function(data) {
    users.forEach(function(user, i) {
      if(user === data) {
        users.splice(i, 1)
        io.emit('all users', users)
      }
    })
  })

  socket.on('disconnect', function(socket) {
    console.log('A User Disconnected')
  })

  socket.on('message', function(data) {
    console.log('Message Event', data)
    io.emit('server message', data)
  })
})

app.use(express.static('public'))

module.exports = server