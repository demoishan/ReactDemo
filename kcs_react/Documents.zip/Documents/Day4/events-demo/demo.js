var express = require('express')
var events = require('events')
var eventEmitter = new events.EventEmitter()

var app = express()

app.get('/', function(req, res) {
  eventEmitter.emit('test event')
  res.send('home')
})

eventEmitter.on('test event', function() {
  console.log('Test Event Triggered!')
})

app.listen(3000, function() {
  console.log('server started')
})