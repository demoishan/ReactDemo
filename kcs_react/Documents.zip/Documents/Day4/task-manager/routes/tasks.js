var express = require('express')
var router = express.Router()
var TasksController = require('../controllers/TasksController')
var AuthMiddleware = require('../middlewares/auth')

router.get('/', AuthMiddleware.authenticate)

router.get('/', TasksController.getTasks)
router.get('/create', TasksController.createTask)
router.post('/', TasksController.addTask)
router.get('/:id', TasksController.getSingleTask) 
router.get('/:id/edit', TasksController.editTask)
router.post('/:id', TasksController.updateTask)
router.get('/:id/delete', TasksController.deleteTask)
router.get('/:id/status', TasksController.toggleStatus)

module.exports = router