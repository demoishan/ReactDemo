var express = require('express')
var router = express.Router()
var DashboardController = require('../controllers/DashboardController')
var AuthMiddleware = require('../middlewares/auth')

router.get('/', [
  AuthMiddleware.authenticate,
  DashboardController.index
])

module.exports = router