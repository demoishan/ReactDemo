var router = require('express').Router()
var AuthController = require('../controllers/AuthController')
var Validate = require('../middlewares/validation')

router.get('/login', AuthController.loginForm)
router.post('/login', [Validate.login, AuthController.login])
router.get('/register', AuthController.registerForm)
router.post('/register', AuthController.register)
router.get('/logout', AuthController.logout)

module.exports = router