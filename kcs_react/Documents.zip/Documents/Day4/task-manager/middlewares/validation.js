exports.login = function(req, res, next) {
  var username = req.body.username
  var password = req.body.password
  
  var errors = {}

  if(username === '') errors.username = 'Username can not be blank.'
  if(password === '') errors.password = 'Password can not be blank.'

  if(Object.keys(errors).length === 0) {
    next()
  } else {
    req.session.errors = errors
    res.redirect('/login')
  }
}