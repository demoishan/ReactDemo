exports.index = function (req, res) {
  console.log(req.session)
  res.render('dashboard/index', {
    user: req.session.user
  })
}