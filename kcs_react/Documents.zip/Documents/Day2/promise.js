(async function() {
  var testPromise = new Promise(function(resolve, reject) {
    setTimeout(function() {
      resolve('abcd')
    }, 2000)
  })
  
  var data = await testPromise
  
  console.log(data)
  
  console.log('Hello')
})()


// testPromise.then(function(data) {
//   console.log('Success!', data)
// }).catch(function() {
//   console.log('Failure.')
// })

// console.log('Hello')