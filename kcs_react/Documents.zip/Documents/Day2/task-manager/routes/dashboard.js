var express = require('express')
var router = express.Router()
var DashboardController = require('../controllers/DashboardController')

router.get('/', DashboardController.index)

module.exports = router