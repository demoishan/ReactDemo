exports.loginForm = function(req, res) {
  res.render('auth/login')
}

exports.login = function(req, res) {
  if(req.body.username === 'admin' && req.body.password === 'admin') {
    res.redirect('/dashboard')
  } else {
    res.redirect('/login')
  }
}

exports.registerForm = function(req, res) {
  res.render('auth/register')
}

exports.register = function(req, res) {
  res.send('register Process works!')
}

exports.logout = function(req, res) {
  res.redirect('/')
}