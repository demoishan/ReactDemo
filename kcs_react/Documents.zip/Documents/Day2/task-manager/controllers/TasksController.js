var Task = require('../models/Task')
var taskItems = require('../models/tasks-src')

exports.getTasks = function(req, res) {
  res.render('tasks', {
    tasks: taskItems
  })
}

exports.createTask = function(req, res) {
  res.render('tasks/form')
}

exports.addTask = function(req, res) {
  var title = req.body.title
  var description = req.body.description

  var task = new Task(
    taskItems.length + 1,
    title,
    description
  )

  taskItems.push(task)

  res.redirect('/tasks')
}

exports.getSingleTask = function(req, res) {
  var id = req.params.id
  var currentTask = null

  for(var i=0; i<taskItems.length; i++) {
    if(id == taskItems[i].id) {
      currentTask = taskItems[i]
      break
    }
  }

  res.render('tasks/details', {
    task: currentTask
  })  
}

exports.editTask = function(req, res) {
  res.render('tasks/form')  
}

exports.updateTask = function(req, res) {
  res.send('Edit process works!')
}

exports.deleteTask = function(req, res) {
  var id = req.params.id

  taskItems.forEach(function(task, i) {
    if(task.id == id) {
      taskItems.splice(i, 1)    
    }
  })

  res.redirect('/tasks')
}

exports.toggleStatus = function(req, res) {
  var id = req.params.id

  taskItems.forEach(function(task) {
    if(task.id == id) {
      task.completed = !task.completed    
    }
  })

  res.redirect('/tasks')
}