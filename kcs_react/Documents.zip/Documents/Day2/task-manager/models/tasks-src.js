var Task = require('./Task')

module.exports = [
  new Task(1, 'Learn NodeJS', 'This is for learning NodeJS'),
  new Task(2, 'Learn ReactJS', 'This is for learning ReactJS'),
  new Task(3, 'Learn Angular', 'This is for learning Angular'),
  new Task(4, 'Learn VueJS', 'This is for learning VueJS'),
  new Task(5, 'Learn ES6', 'This is for learning ES6'),
]