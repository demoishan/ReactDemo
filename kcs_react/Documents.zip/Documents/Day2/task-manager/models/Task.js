var Task = function(id, title, description) {
  this.id = id
  this.title = title
  this.description = description
  this.completed = false
  this.date = new Date()
}

module.exports = Task