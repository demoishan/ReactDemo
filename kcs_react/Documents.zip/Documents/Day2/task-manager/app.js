var express = require('express')
var bodyParser = require('body-parser')

var tasksRouter = require('./routes/tasks')
var dashboardRouter = require('./routes/dashboard')
var authRouter = require('./routes/auth')

var app = express()

app.use(bodyParser.urlencoded({ extended: false }))
app.use(bodyParser.json())

app.set('view engine', 'ejs')

app.get('/', function(req, res) {
  res.redirect('/login')
})

app.use('/', authRouter)
app.use('/tasks', tasksRouter)
app.use('/dashboard', dashboardRouter)

app.get('/*', function(req, res) {
  res.render('shared/pagenotfound')
})

module.exports = app