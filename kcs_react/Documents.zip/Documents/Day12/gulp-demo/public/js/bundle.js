const sayHello = () => {
  console.log('hi')
};

sayHello();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFwcC5qcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBIiwiZmlsZSI6ImJ1bmRsZS5qcyIsInNvdXJjZXNDb250ZW50IjpbImNvbnN0IHNheUhlbGxvID0gKCkgPT4ge1xyXG4gIGNvbnNvbGUubG9nKCdoaScpXHJcbn07XHJcblxyXG5zYXlIZWxsbygpOyJdfQ==