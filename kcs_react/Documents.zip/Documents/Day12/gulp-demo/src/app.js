const sayHello = () => {
  console.log('hi')
};

sayHello();