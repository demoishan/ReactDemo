const { src, dest, parallel } = require('gulp');
const concat = require('gulp-concat');
const eslint = require('gulp-eslint');

function js() {
  return src('src/*.js', { sourcemaps: true })
    .pipe(concat('bundle.js'))
    .pipe(eslint())
    .pipe(dest('public/js', { sourcemaps: true }));
}

exports.js = js;
exports.default = parallel(js);