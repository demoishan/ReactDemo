var fs = require('fs')

fs.writeFileSync('./db.json', 'TEST')

var data = fs.readFileSync('./db.json')

console.log(data.toString())