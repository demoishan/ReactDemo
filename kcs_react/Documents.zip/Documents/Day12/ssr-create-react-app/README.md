Server Side Rendering with Create React App
===========================================

I wanted to add server side rendering to create react app, especially after I added an api server side, based on: https://medium.com/@patriciolpezjuri/using-create-react-app-with-react-router-express-js-8fa658bf892d#.sckywa9cy

Included: redux, react-router

_Warning: uses react-router 3, v4 just dropped, it breaks everything its kinda annoying_

Install
-------
```bash
# Why aren't you using yarn already?
npm i -g yarn
yarn
yarn run build
yarn run start:server
```
