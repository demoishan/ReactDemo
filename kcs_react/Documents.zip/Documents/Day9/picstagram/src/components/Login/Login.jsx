import React, { Component } from 'react'
import {
  Form,
  FormGroup,
  Button,
  Input,
  Label,
  Row,
  Col
} from 'reactstrap'

class Login extends Component {
  render() {
    return (
      <Row>
        <Col md={6}>
          <Form>
            <FormGroup>
              <Label for="username">Username</Label>
              <Input id="username" name="username" />
            </FormGroup>

            <FormGroup>
              <Label for="password">Password</Label>
              <Input type="password" id="password" name="password" />
            </FormGroup>

            <Button type="submit" color="primary">Login</Button>
          </Form>
        </Col>
      </Row>
    )
  }
}

export default Login