import React, { Fragment } from 'react'
import { Route } from 'react-router-dom'

import Profile from './Profile/Profile.jsx'
import PostForm from './PostForm/PostForm'

function Picstagram(props) {
    return (
      <Fragment>
        <Route path='/profile' component={Profile} />
        <Route path='/add' component={PostForm} />
      </Fragment>
    )    
}

export default Picstagram