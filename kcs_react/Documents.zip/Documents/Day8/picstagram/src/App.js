import React, { Fragment } from 'react';

import Header from './components/shared/Header/Header.jsx'
import Nav from './components/shared/Nav/Nav.jsx'
import Footer from './components/shared/Footer/Footer.jsx'
import Picstagram from './components/Picstagram/Picstagram.jsx'

function App() {
  return (
    <Fragment>
      <Nav />
      <div className="container">
        <div className="row">
          <div className="col">
            <Header />
          </div>
        </div>

        <div className="row">
          <div className="offset-md-1 col-md-10">
            <Picstagram />
          </div>
        </div>

        <div className="row">
          <div className="col">
            <Footer />      
          </div>
        </div>
      </div>
    </Fragment>
  );
}

export default App;
