import { ADD_POST, REMOVE_POST } from '../actions/postActions'
import Post from '../models/Post'

export function postReducer(state = [ new Post(1, 'Trying React', 'This is to try reactJS', 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQeE3ZkoFkjH1jTDZsCxi1r8kZZviS9tPSxbiZqq55X6LToG591') ], action) {
  switch(action.type) {
    case ADD_POST:
      const newPost = new Post(
        state.length + 1,
        action.post.caption,
        action.post.description,
        action.post.imageUrl
      )

      return [
        ...state,
        newPost
      ]

    case REMOVE_POST:

    default:
      return state
  }
}