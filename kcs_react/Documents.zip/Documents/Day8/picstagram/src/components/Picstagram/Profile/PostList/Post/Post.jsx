import React from 'react'
import { Col } from 'reactstrap'

function Post(props) {

  const { post } = props

  return (
    <Col md={4} className="mb-4">
      <img className="img-thumbnail" src={post.imageUrl} alt={post.caption} />
      <small>{post.caption}</small>
    </Col>
  )
}

export default Post