import React from 'react'
import { Row } from 'reactstrap'
import { connect } from 'react-redux'

import PostItem from './Post/Post.jsx'

function PostList(props) {
  console.log(props)
  return (
    <Row className="mt-4">
      {
        props.posts.map((post) => {
          return (
            <PostItem key={post.id} post={post} />
          )
        })
      }
    </Row>
  )
}

function mapStateToProps(state) { //state = store.getState()
  return {
    posts: state.posts
  }  
}

export default connect(mapStateToProps)(PostList)