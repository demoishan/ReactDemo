import React, { Fragment } from 'react'
import { Row, Col } from 'reactstrap'

import PostList from './PostList/PostList.jsx'
import ProfileHeader from './ProfileHeader/ProfileHeader.jsx'
import PostForm from '../PostForm/PostForm.jsx'

function Profile(props) {
  return (
    <Fragment>
      <Row>
        <Col>
          {/* <ProfileHeader /> */}
          <PostForm addPost={props.addPost} />
        </Col>
        <Col>
          <PostList posts={props.posts}/>
        </Col>
      </Row>

      {/* <Row>
        <Col>
          <PostList />
        </Col>
      </Row> */}
    </Fragment>
  )
}

export default Profile