import React from 'react'
import Profile from './Profile/Profile.jsx'

function Picstagram(props) {
    return <Profile />    
}

export default Picstagram