export const ADD_POST = 'ADD_POST'
export const REMOVE_POST = 'REMOVE_POST'

export const addPostAction = (post) => {
  return {
    type: ADD_POST,
    post
  }
}

export const removePostAction = (id) => {
  return {
    type: REMOVE_POST,
    id
  }
}