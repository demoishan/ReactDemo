import { EVEN_INCR, EVEN_DECR } from '../actions/evenCounterActions'

export function evenCounterReducer(state=0, action) {
  switch(action.type) {
    case EVEN_DECR:
      return state - 2
    
    case EVEN_INCR:
      return state + 2

    default:
      return state
  }
}