export const EVEN_INCR = 'EVEN_INCR'
export const EVEN_DECR = 'EVEN_DECR'

export const evenIncrAction = () => {
  return {
    type: EVEN_INCR
  }
}

export const evenDecrAction = () => {
  return {
    type: EVEN_DECR  
  }
}