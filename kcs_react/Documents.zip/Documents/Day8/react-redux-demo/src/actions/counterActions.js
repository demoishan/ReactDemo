export const INCR = 'incr'
export const DECR = 'decr'

export const incrAction = () => {
  return {
    type: INCR
  }
}

export const decrAction = () => {
  return {
    type: DECR
  }
}