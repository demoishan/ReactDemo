import React from 'react';
import './App.css';
import Counter from './components/Counter.jsx'
import EvenCounter from './components/EvenCounter.jsx'

function App(props) {
  return (
    <div className="App">
      <h1>Counter</h1>
      <Counter store={props.store}/>
      
      <hr />
      <h1>Even Counter</h1>
      <EvenCounter store={props.store} />
    </div>
  );
}

export default App;
