import React, { Component } from 'react'
import { evenIncrAction, evenDecrAction } from '../actions/evenCounterActions'

class EvenCounter extends Component {
  decr = () => {
    this.props.store.dispatch(evenDecrAction())
  }

  incr = () => {
    this.props.store.dispatch(evenIncrAction())
  }

  render() {
    return (
      <div>
        <h2>{this.props.store.getState().evenCounter}</h2>
        <button onClick={this.incr}>+</button>
        <button onClick={this.decr}>-</button>
      </div>
    )
  }
}

export default EvenCounter