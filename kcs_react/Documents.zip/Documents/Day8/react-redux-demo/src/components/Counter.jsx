import React, { Component } from 'react'
import { incrAction, decrAction } from '../actions/counterActions'

class Counter extends Component {
  decr = () => {
    this.props.store.dispatch(decrAction())
  }

  incr = () => {
    this.props.store.dispatch(incrAction())
  }

  render() {
    return (
      <div>
        <h2>{this.props.store.getState().counter}</h2>
        <button onClick={this.incr}>+</button>
        <button onClick={this.decr}>-</button>
      </div>
    )
  }
}

export default Counter