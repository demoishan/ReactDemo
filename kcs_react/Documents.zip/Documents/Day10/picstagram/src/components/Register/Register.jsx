import React, { Component } from 'react'

class Register extends Component {
  render() {
    return <p>Register Works!</p>
  }
}

export default Register