import React from 'react'

function Footer(props) {
  return (
    <div>
      <hr />
      <small>&copy; KrishCompusoft</small>
    </div>
  )
}

export default Footer