class Post {
  constructor(id, caption, description, imageUrl) {
    this.id = id
    this.caption = caption
    this.description = description
    this.imageUrl = imageUrl
  }
}

export default Post