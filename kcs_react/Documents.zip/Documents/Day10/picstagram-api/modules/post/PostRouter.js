const { Router } = require('express')
const PostsController = require('./controllers/PostsController')
const postValidator = require('./validators/postValidator')

const router = Router()

router.get('/', PostsController.getAllPosts)
router.get('/:id', PostsController.getSinglePost)
router.post('/', [postValidator, PostsController.createPost])
router.delete('/:id', PostsController.removePost)

module.exports = router