let a = 10;
const age = 20;

if(true) {
  let a = 20;
}

console.log(a)