'use strict';

const personalDetails = {
  name: 'John',
  email: 'john@gmail.com',
  age: 30
}

const loginDetails = {
  username: 'j.d',
  password: 'abcd'
}

// const userDetails = Object.assign({}, personalDetails, loginDetails)
// const userDetails = {
//   ...loginDetails,
//   ...personalDetails
// }

// console.log(userDetails)

// const { name, age, email } = student

// const marks = [10, 20, 30, 40]

// const [name, email, age] = marks

// console.log(name, email, age)


// const marks1 = [1,2,3,4]
// const marks2 = [4,5,6,7]

// const marks3 = [
//   ...marks1,
//   ...marks2
// ]

// console.log(marks3)

function sayHi(name, ...details) {
  console.log(name, details)
}

sayHi('Ravi', 'test', '123', 456);







