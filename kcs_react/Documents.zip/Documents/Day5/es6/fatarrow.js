class Task {
  constructor(id, title) {
    this.id = id
    this.title = title
  }

  showDetails() {
    console.log(this.id, this.title)
  }
}

// var Task = function(id, title) {
//   this.id = id;
//   this.title = title;
// }

// Task.prototype.showDetails = function() {
//   console.log(this.id, this.title)
// }

var task = new Task(1, 'Test')

task.showDetails()

// var sayHello = user => `Hello ${user}!!!!`

// console.log(sayHello('Ravi'))