const id = 1
const title = 'ABCd'

const Task = function(id, title) {
  this.id = id;
  this.title = title;
}

const task = new Task(1, 'test')

showDetails = function() {
  console.log(this)
}

showDetails = showDetails.bind(task)

showDetails();

// ReactJS
// this.showDetails = this.showDetails.bind(this)
