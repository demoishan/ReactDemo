// const Task = require('./class.task')

import asdf, { limit, Task } from './class.task'

const task = new Task(1, 'test')

task.showDetails()