export class Task {
  constructor(id, title) {
    this.id = id;
    this.title = title;
  }
  
  showDetails() {
    console.log(this.title, this.id)
  }
}

export const limit = 10;

// module.exports = Task
// export default Task

const PI = 3.14

export default PI