import testmodule from './testmodule'

const test = testmodule

console.log('This is index.', test)