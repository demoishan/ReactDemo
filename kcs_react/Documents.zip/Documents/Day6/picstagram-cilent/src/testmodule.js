const testmodule = {
  msg: 'Inside Test Module'
}

export default testmodule