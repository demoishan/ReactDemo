import React from 'react'

import Welcome from './Welcome'

function App(props) {
  return (
    <div>
      <Welcome name="Bhavesh"/>
      <Welcome name="Chirag"/>
      <Welcome name="Amit"/>
      <Welcome name="Sanket"/>
    </div>
  )
}

export default App