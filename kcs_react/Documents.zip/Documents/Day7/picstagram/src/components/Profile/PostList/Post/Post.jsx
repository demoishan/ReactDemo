import React from 'react'
import { Col } from 'reactstrap'

function Post(props) {
  return (
    <Col md={4} className="mb-4">
      <img className="img-thumbnail" src="http://www.sfsdekpax.com/image/11-PCS-Multi-Photo-Frame-Frames-Love-Family-Picture-Wall.jpg" alt="" />
    </Col>
  )
}

export default Post