import React from 'react'
import { Row } from 'reactstrap'

import Post from './Post/Post.jsx'

function PostList(props) {
  return (
    <Row className="mt-4">
      {
        [1,2,3,4,5,6,7].map((i) => {
          return (
            <Post key={i}/>
          )
        })
      }
    </Row>
  )
}

export default PostList