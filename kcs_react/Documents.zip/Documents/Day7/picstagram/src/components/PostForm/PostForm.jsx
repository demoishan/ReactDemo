import React from 'react'
import {
  Form,
  Label,
  Input,
  Button,
  FormGroup
} from 'reactstrap'

function PostForm(props) {
  return (
    <Form>
      <h2>Add Post</h2>
      <hr />

      <FormGroup>
        <Label for="caption">Caption</Label>
        <Input type="text" id="caption" />
      </FormGroup>

      <FormGroup>
        <Label for="description">Description</Label>
        <Input type="textarea" id="description" />
      </FormGroup>

      <FormGroup>
        <Label for="imageUrl">Image Url</Label>
        <Input type="text" id="imageUrl" />
      </FormGroup>

      <Button type="submit" color="primary">Add</Button>
    </Form>
  )
}

export default PostForm