
  //Include mongoose
  var mongoose = require('mongoose')

  //Connect to mongodb
  mongoose.connect(
    'mongodb://localhost:27018/taskManager', 
    { useNewUrlParser: true }, 
    function(err) {
      if(err) {
        console.log(err)
      } else {
        console.log('DB Connected!')
      }
    }
  )

  //Create Schema
  var TaskSchema = new mongoose.Schema({
    title: { type: String, required: true },
    description: { type: String },
    completed: { type: Boolean, default: false },
  }, {
    timestamps: true
  })

  //Create Model based on Schema
  var Task = mongoose.model('Task', TaskSchema);

  //Query the database
  // Task.find().then(function(data) {
  //   console.log(data)
  // })

(async function() {
  var data = await Task.find()

  console.log(data)
})()
