var Task = require('../models/Task')

exports.getTasks = function(req, res) {
  Task.find().then(function(taskItems) {
    res.render('tasks', {
      tasks: taskItems
    })
  });
}

exports.createTask = function(req, res) {
  res.render('tasks/form')
}

exports.addTask = function(req, res) {
  var title = req.body.title
  var description = req.body.description

  var task = new Task()

  task.title = title
  task.description = description

  task.save().then(function() {
    res.redirect('/tasks')
  }).catch(function() {
    res.redirect('/tasks')
  })
}

exports.getSingleTask = function(req, res) {
  var id = req.params.id
  
  Task.findById(id).then(function(currentTask) {
    res.render('tasks/details', {
      task: currentTask
    })
  })  
}

exports.editTask = function(req, res) {
  res.render('tasks/form')  
}

exports.updateTask = function(req, res) {
  res.send('Edit process works!')
}

exports.deleteTask = function(req, res) {
  var id = req.params.id

  Task.findByIdAndRemove(id).then(function() {
    res.redirect('/tasks')
  })
}

exports.toggleStatus = async function(req, res) {
  var id = req.params.id

  var task = await Task.findById(id)
  console.log(task.completed)
  task.completed = !task.completed
  await task.save()
  res.redirect('/tasks')

  // Task.findById(id)
  //   .then(function(task) {
  //     task.completed = !task.completed
  //     return task.save()
  //   })
  //   .then(function() {
  //     res.redirect('/tasks')
  //   })
}