var bcrypt = require('bcryptjs')
var User = require('../models/User')

exports.loginForm = function(req, res) {
  res.render('auth/login')
}

exports.login = function(req, res) {
  User.findOne({ username: req.body.username })
    .then(function(user) {
      var valid = bcrypt.compareSync(req.body.password, user.passwordHash)

      if(valid) {
        res.redirect('/dashboard')
      } else {
        res.redirect('/login')
      }
    })
    .catch(function() {
      res.redirect('/login')
    })
  
  // if(req.body.username === 'admin' && req.body.password === 'admin') {
  //   res.redirect('/dashboard')
  // } else {
  //   res.redirect('/login')
  // }
}

exports.registerForm = function(req, res) {
  res.render('auth/register')
}

exports.register = function(req, res) {
  var data = req.body

  var salt = bcrypt.genSaltSync(10)
  data.passwordHash = bcrypt.hashSync(data.password, salt)

  delete data.confirmPassword
  delete data.password

  User.create(data).then(function(user) {
    console.log(user)
    res.redirect('/')
  })
}

exports.logout = function(req, res) {
  res.redirect('/')
}