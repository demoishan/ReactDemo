var mongoose = require('mongoose')

var UserSchema = new mongoose.Schema({
  name: { type: String, required: true },
  email: { type: String, required: true, unique: true },
  username: { type: String, required: true, unique: true, maxlength: 50 },
  passwordHash: { type: String, required: true }
}, {
  timestamps: true
})

module.exports = mongoose.model('User', UserSchema)