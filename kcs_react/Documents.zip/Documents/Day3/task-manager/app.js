var express = require('express')
var bodyParser = require('body-parser')
var mongoose = require('mongoose')

var tasksRouter = require('./routes/tasks')
var dashboardRouter = require('./routes/dashboard')
var authRouter = require('./routes/auth')

mongoose.connect(
  'mongodb://localhost:27018/taskManager',
  { useNewUrlParser: true },
  function(err) {
    if(!err) console.log('DB Connected!')
  }
)

var app = express()

app.use(bodyParser.urlencoded({ extended: false }))
app.use(bodyParser.json())

app.set('view engine', 'ejs')

app.get('/', function(req, res) {
  res.redirect('/login')
})

app.use('/', authRouter)
app.use('/tasks', tasksRouter)
app.use('/dashboard', dashboardRouter)

app.get('/*', function(req, res) {
  res.render('shared/pagenotfound')
})

module.exports = app